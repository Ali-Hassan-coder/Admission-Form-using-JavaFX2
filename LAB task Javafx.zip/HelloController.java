package com.example.admissionformusingjavafx;


import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class HelloController extends Application {

    @Override
    public void start(Stage primaryStage) {
        // Create a GridPane layout
        GridPane gridPane = new GridPane();
        gridPane.setHgap(20);
        gridPane.setVgap(20);
        gridPane.setStyle("-fx-padding: 20; -fx-background-color: #f0f0f0;");


        Image image = new Image("C:\\Users\\mb\\OneDrive\\Pictures\\Profile Picture.PNG"); // Replace "file:logo.png" with the path to your image
        ImageView imageView = new ImageView(image);
        imageView.setFitHeight(100);
        imageView.setFitWidth(100);
        imageView.setPreserveRatio(true);
        gridPane.add(imageView, 0, 0, 2, 1); 


        Label nameLabel = new Label("Name:");
        TextField nameField = new TextField();

        Label ageLabel = new Label("Age:");
        TextField ageField = new TextField();

        Label genderLabel = new Label("Gender:");
        ToggleGroup genderGroup = new ToggleGroup();
        RadioButton maleButton = new RadioButton("Male");
        maleButton.setToggleGroup(genderGroup);
        RadioButton femaleButton = new RadioButton("Female");
        femaleButton.setToggleGroup(genderGroup);
        HBox genderBox = new HBox(10, maleButton, femaleButton);

        Label courseLabel = new Label("Course:");
        ComboBox<String> courseBox = new ComboBox<>();
        courseBox.getItems().addAll("Computer Science", "Information Technology", "Mechanical Engineering", "Civil Engineering");

        Label addressLabel = new Label("Address:");
        TextArea addressArea = new TextArea();
        addressArea.setPrefRowCount(3);

        Button submitButton = new Button("Submit");
        submitButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white;");
        submitButton.setOnAction(e -> {
            String name = nameField.getText();
            String age = ageField.getText();
            String gender = maleButton.isSelected() ? "Male" : femaleButton.isSelected() ? "Female" : "Not Specified";
            String course = courseBox.getValue() != null ? courseBox.getValue() : "Not Selected";
            String address = addressArea.getText();
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Admission Form Submitted");
            alert.setHeaderText("Your Details:");
            alert.setContentText("Name: " + name + "\nAge: " + age + "\nGender: " + gender +
                    "\nCourse: " + course + "\nAddress: " + address);
            alert.showAndWait();
        });


        gridPane.add(nameLabel, 0,1 );
        gridPane.add(nameField, 1, 1);

        gridPane.add(ageLabel, 0, 2);
        gridPane.add(ageField, 1, 2);

        gridPane.add(genderLabel, 0, 3);
        gridPane.add(genderBox, 1, 3);

        gridPane.add(courseLabel, 0, 4);
        gridPane.add(courseBox, 1, 4);

        gridPane.add(addressLabel, 0, 5);
        gridPane.add(addressArea, 1, 5);

        gridPane.add(submitButton, 1, 6);

        // Set up the Scene and Stage
        Scene scene = new Scene(gridPane, 400, 500);

        primaryStage.setTitle("Admission Form");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
